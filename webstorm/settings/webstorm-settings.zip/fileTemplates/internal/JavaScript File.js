/*
  Created by IntelliJ IDEA.
  User: icechen1219
  Date: ${YEAR}/${MONTH}/${DAY}
  Time: ${TIME}
  To change this template use File | Settings | File Templates.
*/
"use strict";
${END}
